
// Autor: Adrian Bennasar Polzin. Enlace al video: https://youtu.be/oDwXqFTk2MM

package banymixtv2;

import java.util.concurrent.Semaphore; // libreria para utilizacion de semaforos.

public class BanyMixtV2 {

    static Semaphore banyBuit = new Semaphore(1); // bloquear hombre si el primero en entrar es una mujer y viceversa.
    static Semaphore home = new Semaphore(1); // exclusión mútua entre procesos del tipo Home.
    static Semaphore dona = new Semaphore(1); // exclusión mútua entre procesos del tipo Dona.
    static Semaphore cont_home = new Semaphore(3); // control de la capacidad máxima del baño.
    static Semaphore cont_dona = new Semaphore(3); // control de la capacidad máxima del baño.
    static Semaphore barreraInanicio = new Semaphore(1); // prevenir inanición de los procesos.

    static int contD = 0; // para saber si una mujer ha sido la primera en llegar. Tamnién para saber cuando el baño queda vacio
                          // después de usarse por una o varias mujeres.
    static int contH = 0; // para saber si un hombre ha sido la primera en llegar. Tamnién para saber cuando el baño queda vacio
                          // después de usarse por uno o varios hombres.

    static final int DONES = 6; // cantidad de mujeres en la simulación. final porque NO debe variar durante la ejecución.
    static final int HOMES = 6; // cantidad de hombres en la simulación. final porque NO debe variar durante la ejecución.

    static String[] poolNoms = {"AINA", "GORI", "GERONIA", "COSME", "FRANCESCA", // pool de nombres para poner identificadores a los
        "JAUME", "JOANA", "DAMIA", "ELISABET", "ANTONI",                         // procesos.
        "CATALINA", "BERNAT"};

    public static void main(String[] args) throws InterruptedException {

        Thread[] threads = new Thread[DONES + HOMES]; // array que contiene los threads que harán la simulación.

        /* Lanzamiento de threads intercalando 1 mujer y 1 hombre 
           para intentar ser "justos". */
        for (int i = 0; i < (DONES + HOMES); i++) {
            if ((i % 2) == 0){
                threads[i] = new Thread(new Dona(poolNoms[i]));
            }else{
                threads[i] = new Thread(new Home(poolNoms[i]));
            }
        }
        for (int i = 0; i < (DONES + HOMES); i++) {
            threads[i].start();
        }

        /* Bucle join. El programa principal esperará a que acaben los threads 
           antes de cerrar la ejecución del programa. */
        for (int i = 0; i < DONES + HOMES; i++) {
            threads[i].join();
        }

    }
}
