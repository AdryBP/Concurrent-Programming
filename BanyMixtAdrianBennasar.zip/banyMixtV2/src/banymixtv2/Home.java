package banymixtv2;

import java.util.Random;

public class Home implements Runnable {

    private String id;
    private int contEntradas;

    public Home(String id) { // Constructor de clase.
        this.id = id; // Asignación de identificador.
        contEntradas = 0; // Inicialización del contador de entradas.
        System.out.println(this.id + " arriba al despatx"); // Informa de que ha sido lanzado.
    }

    private void treballa() throws InterruptedException { // método que representa la simulación.
        
        // preprotocolo
        
        System.out.println(this.id + " treballa");
        Thread.sleep((new Random().nextInt(2) + 1) * 1000); // esperan un tiempo aleatorio para que no entre primero siempre el mismo.
        BanyMixtV2.barreraInanicio.acquire(); // evitamos inanición de procesos.
            BanyMixtV2.home.acquire(); // exclusión mútua consulta/modificación de variables.
                BanyMixtV2.contH = BanyMixtV2.contH + 1; // sumamos 1 a la cantidad de hombres que quieren entrar.
                if (BanyMixtV2.contH == 1) { // si es el primer hombre en entrar.
                    BanyMixtV2.banyBuit.acquire(); // coge el único permiso de este semáforo, bloqueando a las mujeres.
                }
            BanyMixtV2.home.release(); // exclusión mútua consulta/modificación de variables.
        BanyMixtV2.barreraInanicio.release(); // evitamos inanición de procesos.
        BanyMixtV2.cont_home.acquire(); // se resta un permiso al semáforo que controla la capacidad máxima.
    
        // entrada al baño
        
        BanyMixtV2.home.acquire(); // exclusión mútua consulta/modificación de variables.
            this.contEntradas++; // actualización contador de entradas.
            System.out.println(this.id + " entra " + this.contEntradas + "/2. " + "Homes al bany: " + BanyMixtV2.contH); // información
        BanyMixtV2.home.release(); // exclusión mútua consulta/modificación de variables.
        Thread.sleep((new Random().nextInt(3) + 1) * 1000); // representa estar dentro del baño.
        
        // postprotocolo
        
        BanyMixtV2.cont_home.release(); // se devuelve un permiso al semáforo de capacidad máxima.
        BanyMixtV2.home.acquire(); // exclusión mútua consulta/modificación de variables.
            BanyMixtV2.contH = BanyMixtV2.contH - 1; // un hombre menos dentro del baño.
            System.out.println(this.id + " surt.");
            if (BanyMixtV2.contH == 0) { // si no quedan hombres en el baño.
                System.out.println("*** El bany esta buit ***");
                BanyMixtV2.banyBuit.release(); // liberamos mujeres bloqueadas.
            }
        BanyMixtV2.home.release(); // exclusión mútua consulta/modificación de variables.
    }

    @Override
    public void run() {
        while (contEntradas < 2) { // van al baño 2 veces durante el trabajo.
            try {
                treballa(); // simulación acceso al baño.
            } catch (InterruptedException ex) {
            }
        }
        System.out.println(this.id + " Acaba la feina.");
    }

}
