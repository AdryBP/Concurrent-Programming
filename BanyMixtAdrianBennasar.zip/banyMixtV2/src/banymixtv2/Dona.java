package banymixtv2;

import java.util.Random;

public class Dona implements Runnable {

    private String id;
    private int contEntradas;

    public Dona(String id) { // Constructor de clase.
        this.id = id; // Asignación de identificador.
        contEntradas = 0; // Inicialización del contador de entradas.
        System.out.println(this.id + " arriba al despatx"); // Informa de que ha sido lanzado.
    }

    private void treballa() throws InterruptedException { // método que representa la simulación.
        
        // preprotocolo
        
        System.out.println(this.id + " treballa");
        Thread.sleep((new Random().nextInt(2) + 1) * 1000); // esperan un tiempo aleatorio para que no entre primero siempre el mismo.
        BanyMixtV2.barreraInanicio.acquire(); // evitamos inanición de procesos.
            BanyMixtV2.dona.acquire(); // exclusión mútua consulta/modificación de variables.
                BanyMixtV2.contD = BanyMixtV2.contD + 1; // sumamos 1 a la cantidad de mujeres que quieren entrar.
                if (BanyMixtV2.contD == 1) { // si es la primera mujer en entrar.
                    BanyMixtV2.banyBuit.acquire(); // coge el único permiso de este semáforo, bloqueando a los hombres.
                }
            BanyMixtV2.dona.release(); // exclusión mútua consulta/modificación de variables.
        BanyMixtV2.barreraInanicio.release(); // evitamos inanición de procesos.
        BanyMixtV2.cont_dona.acquire(); // se resta un permiso al semáforo que controla la capacidad máxima.
    
        // entrada al baño
        
        BanyMixtV2.dona.acquire(); // exclusión mútua consulta/modificación de variables.
            this.contEntradas++; // actualización contador de entradas.
            System.out.println(this.id + " entra " + this.contEntradas + "/2. " + "Dones al bany: " + BanyMixtV2.contD); // información.
        BanyMixtV2.dona.release(); // exclusión mútua consulta/modificación de variables.
        Thread.sleep((new Random().nextInt(3) + 1) * 1000); // representa estar dentro del baño.
        
        // postprotocolo
        
        BanyMixtV2.cont_dona.release(); // se devuelve un permiso al semáforo de capacidad máxima.
        BanyMixtV2.dona.acquire(); // exclusión mútua consulta/modificación de variables.
            BanyMixtV2.contD = BanyMixtV2.contD - 1; // una mujer menos dentro del baño.
            System.out.println(this.id + " surt.");
            if (BanyMixtV2.contD == 0) { // si no quedan mujeres en el baño.
                System.out.println("*** El bany esta buit ***");
                BanyMixtV2.banyBuit.release(); // liberamos hombres bloqueados.
            }
        BanyMixtV2.dona.release(); // exclusión mútua consulta/modificación de variables.
    }

    @Override
    public void run() {
        while (contEntradas < 2) { // van al baño 2 veces durante el trabajo.
            try {
                treballa(); // simulación acceso al baño.
            } catch (InterruptedException ex) {
            }
        }
        System.out.println(this.id + " Acaba la feina.");
    }

}
